# chproxy

To apply proxy system-wide on linux

## How to use

* Install package: 

	```bash
	pip install chproxy
	```

* Use it from terminal immediately:

	```bash
	chproxy --mode manual --protocol https --host host.proxy.net --port proxy_port
	```	



